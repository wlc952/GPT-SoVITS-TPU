import os
import shutil
import re
import csv
import math
import psutil
import sys
import time
import logging
import argparse
import json
from .buildtree import check_buildtree, BuildTree
from .subp import CommandExecutor
from .util import *
from .logger import init_logger

def parse_stats(string):
    time_match = re.search(r'^Total time = (\d+) cycle$', string, re.MULTILINE)
    if time_match:
        total_time = int(time_match.group(1))
    else:
        assert False, "No time found"
    ret = {}
    ret['time(ms)'] = total_time
        
    version_str = re.findall("Bmodel loaded, version (.*)", string)
    version = version_str[0] if len(version_str) > 0 else "-"
    ret['version'] = version

    shape_info = re.search(r'(?<=bmodel_shape: ).*', string, re.MULTILINE).group(0)
    ret['shape'] = shape_info
    return ret

def read_profile(fn):
    parse_result = parse_profile(fn)
    if not parse_result:
        return
    sum = {}
    for data in parse_result:
        for key,value in data.items():
            if key == 'flops':
                sum[key] = data[key]
                continue
            if key in sum and "vggssd" not in fn:
                sum[key] += data[key]
            else:
                sum[key] = data[key]
    return sum

def parse_profile(fn):
    with open(fn, errors='ignore') as f:
        lines = f.read()
    if not lines:
        return
    lines = re.split('\\s*API_END\\s*|\\s*ENGINE_BD\\s*', lines)[2::2]
    result = []
    for string in lines:
        data = dict()
        for pair in re.finditer('(\w+) *: *([\d\.]+)', string):
            v = pair.group(2)
            data[pair.group(1)] = float(v) if '.' in v else int(v)
        result.append(data)
    return result

def format_float(v):
    if v > 0.1:
        return f'{v:.03f}'
    else:
        return f'{v:.03e}'

def check_tool_installed(tool):
    if not shutil.which(tool):
        logging.error(f'{tool} not installed successfully')
        return False
    return True


def run_model(tree, config, name, b, profile_path, bmodel, stat_f, launch_time_f, extra, cache=False):
    ok, msg = True, ""
    if not os.path.exists(bmodel):
        logging.error(f'{bmodel} does not exist')
        return False, "not-found"
    title = f'run.{config["num_core"]}_{name}'
    workdir = config['workdir']
    env = [
        tree.expand_variables(config, v)
        for v in config.get('run_env', [])]
    pool = CommandExecutor(workdir, env, verbose=True)

    bmodel_dir = os.path.dirname(bmodel)
    info = None
    if os.path.exists(profile_path):
        info = read_profile(profile_path)

    core_suffix = '' if config["num_core"] == 1 else f'_core{config["num_core"]}'
    shape_key = config['shape_key']
    full_name = f'{config["name"]}{core_suffix}-{shape_key} {name}'
    ref_fn = os.path.join(bmodel_dir, 'output_ref_data.dat')
    dev = tree.global_config['devices'][0]
    cmd_opts = ['release_modeling']

    emulator_opts = ['tpu-model-rt']
    ret = check_tool_installed(emulator_opts[0])
    if not ret:
        ok, msg = False, "emulator not installed successfully"
    else:
        rt_cmp = config.get('runtime_cmp', True)
        if rt_cmp:
            if os.path.exists(ref_fn) and os.path.getsize(ref_fn):
                logging.info(f'Runtime compare {full_name}')
                pool.put(
                    'compare-' + title,
                    [*emulator_opts, '--context_dir', bmodel_dir],
                    shell=False)
                try:
                    pool.wait()
                except:
                    ok, msg = False, "compare-failed"
                    logging.error(f'Runtime compare {full_name} {bmodel_dir} failed')
            else:
                logging.warning(f'{full_name} has no reference data')
        else:
            logging.info(f'Runtime compare {full_name} skipped')

    target = tree.global_config['target']
    ret = check_tool_installed(cmd_opts[0])
    runtime_success = True
    if not ret:
        ok, msg = False, "release_modeling not installed successfully"
        runtime_success = False
    else:
        logging.info(f'Runtime test {full_name}')
        pool.put(
            title,
            [*cmd_opts, '--bmodel', bmodel],
            shell=False)
        try:
            pool.fire()
            pid = pool.pipes[0].pid
            p = psutil.Process(pid)
            cpu_percent = p.cpu_percent(interval=1) / 100
            pool.drain()
            pool.procs.clear()
        except RuntimeError:
            ok, msg = False, "bmodel runtime failed"
            logging.error(f'Runtime test {full_name} failed')
                
        runtime_success = ok
    
    # If profile exists, calculate mac & ddr utilization
    mac_configs = {
        'BM1690': {'FP32': 2, 'FP16': 16, 'BF16': 16, 'INT8': 32},
    }
    for chip in ['BM1690']:
        mac_configs[f'{chip}_total'] = {k: v*8 for k, v in mac_configs[chip].items()}
    ddr_configs = {
        'BM1690': 64,
        'BM1690_total': 512
    }
    model_name = f'{config["name"]}{core_suffix}'
    if runtime_success:
        csv_writerow(workdir, title, config, b, model_name, 
                    extra, target, mac_configs, ddr_configs, info, cpu_percent, stat_f, launch_time_f)
    return ok, msg


def csv_writerow(workdir, title, config, b, model_name, extra, target, 
                 mac_configs, ddr_configs, info, cpu_percent, stat_f, launch_time_f, parallel=False):
    if config['num_core'] != 1:
        target += "_total"
    log_fn = os.path.join(workdir, f'{title}.log')
    with open(log_fn, errors='ignore') as f:
        stats = parse_stats(f.read())
    from math import nan
    real_time = stats['time(ms)'] / 1000 / 1000 if 'time(ms)' in stats else nan
    prec = config['prec']
    if prec.startswith('INT8'):
        prec = 'INT8'
    mac_total = mac_configs.get(target).get(prec)
    if 'gops' in config:
        gops = config['gops']
            
    row = [
        model_name,
        stats['version'],
        *[config.get(k, '') for k in extra],
        stats['shape'],
        format_float(gops * b) if 'gops' in config else 'N/A',
        format_float(real_time)]
    ddr_total = ddr_configs.get(target)
    if mac_total is None or ddr_total is None:
        logging.error('Invalid config for {} {}'.format(target, config['prec']))
        raise RuntimeError('Invalid config')

    if 'gops' in config:
        calc_mac_util = lambda t: gops * b / t / mac_total
        row.append(f'{calc_mac_util(real_time):.2%}')
    else:
        logging.warning(f'No GOPs in config.yaml, {config["name"]}')
        row.append('N/A')
    if info is not None:
        s2l = info.get('S2L', math.nan)
        l2s = info.get('L2S', math.nan)
        s2s = info.get('S2S', math.nan)
        ddr_usage = s2l + l2s + s2s * 2
        calc_ddr_bandwidth = lambda t: \
            ddr_usage / t * 1000 / 1024**3 / ddr_total

        est_time = info['runtime']
        row.append(f'{calc_ddr_bandwidth(real_time):.2%}')
    else:
        ext = ['N/A']
        row.extend(ext)
    row.append(f'{cpu_percent:.2%}')

    stat_f.writerow(row)

    return


def run_mlir(tree, path, raw_config, stat_f, launch_time_f, extra, cache=False):
    """
    return tuple, first elem contains succeed cases, second for failed.
    """
    workdir = raw_config['workdir']
    deploies = raw_config.get('deploy', [])
    if not deploies:
        return [raw_config['name']], []

    succeed = []
    failed = []
    
    parser = argparse.ArgumentParser(description='MLIR deploy')
    parser.add_argument(
        "--quantize", default="F32",
        type=str.upper, choices=['F32', 'BF16', 'F16', 'INT8', 'QDQ', 'W4F16', 'W4BF16'],
        help="set default qauntization type: F32/BF16/F16/INT8")
    parser.add_argument(
        "--chip", required=True, type=str.lower,
        choices=['bm1690'],
        help="chip platform name")
    parser.add_argument("--model", required=True, help='output model')
    parser.add_argument(
        "--asymmetric", action='store_true',
        help="do INT8 asymmetric quantization")

    for i, deploy in enumerate(deploies):
        title = f'mlir_deploy_core{raw_config["num_core"]}.{i}'
        cwd = os.path.join(workdir, title)
        deploy = tree.expand_variables(raw_config, deploy)
        args, _ = parser.parse_known_args(deploy.split())
        bmodel = args.model.replace('.bmodel', '/compilation.bmodel')
        profile_path = args.model + '.compiler_profile_0.txt'
        prec = args.quantize
        if re.match('^F\d+$', prec):
            prec = prec.replace('F', 'FP')

        name = prec
        if args.asymmetric:
            name += '-asym'
        raw_config['prec'] = name
        ok, msg = run_model(
            tree, raw_config,
            name,
            1,
            profile_path,
            bmodel if os.path.exists(bmodel) else args.model,
            stat_f, launch_time_f, extra, cache)
        expand_name = os.path.basename(args.model).replace(".bmodel",'')

        if ok:
            succeed.append(' '.join([os.path.basename(raw_config['workdir']),expand_name]))
        else:
            failed.append(' '.join([os.path.basename(raw_config['workdir']),expand_name, f"({msg})"]))

    return succeed, failed

def main():
    init_logger()
    
    parser = argparse.ArgumentParser(description='tpu-perf benchmark tool')
    BuildTree.add_arguments(parser)
    parser.add_argument('--report', type=str, help='report model runtime results to the specified json file')
    parser.add_argument('--use_cache', action='store_true', help='use bmrt_test log as cache to calculate report.')
    parser.add_argument('--parallel', action='store_true', default=False, help='parallel run bmodels')
    parser.add_argument('--launch_time_csv', action='store_true', help='generate launch_time.csv')
    args = parser.parse_args()

    if not check_buildtree():
        sys.exit(1)
        
    if args.use_cache:
        logging.info("cache_mode = True")

    tree = BuildTree(os.path.abspath('.'), args)
    stat_fn = os.path.join(tree.global_config['outdir'], 'stats.csv')
    launch_time_fn = os.path.join(tree.global_config['outdir'], 'launch_time.csv')
    extra = set(['prec'])
    run_func = run_mlir
    extra = list(extra)
    extra.sort()
    ok = True
    succ_cases, failed_cases = [], []
    with open(stat_fn, 'w') as f:
        csv_f = csv.writer(f)
        csv_f.writerow([
            'name',
            'version',
            *extra,
            'shape',
            'gops',
            'time(ms)',
            'mac_utilization',
            'ddr_utilization',
            'cpu_usage'])
        f_l = csv_l = None
        for path, config in tree.walk():
            if config['model_name'] and config['name'] != config['model_name']:
                continue
            if 'parallel' not in config.keys():
                config['parallel'] = False
            if args.parallel:
                config['parallel'] = True
            for i in range(len(config['core_list'])):
                config['num_core'] = config['core_list'][i]
                res = run_func(tree, path, config, csv_f, csv_l, extra, cache=args.use_cache)
                succ_cases.extend(res[0])
                failed_cases.extend(res[1])
                ok = not res[1] and ok
                
        if f_l:
            f_l.close()
    
    if args.report:
        params = {"succ_cases": list(set(succ_cases)), "failed_cases": list(set(failed_cases))}
        with open(f'{args.report}', 'w') as f:
            json.dump(params, f)

    sys.exit(255 if not ok else 0)

if __name__ == '__main__':
    main()
